package com.example.uas_perangkat_bergerak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
